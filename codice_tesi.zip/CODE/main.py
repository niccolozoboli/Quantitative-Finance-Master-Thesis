"""
main.py — Quantitative Finance Master Thesis v2.0
"""

import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

from src.preprocessing     import METALS, load_and_preprocess, reconstruct_prices
from src.walk_forward      import get_walk_forward_folds, aggregate_fold_results
from src.utils             import compute_metrics, save_results
from src.regime            import classify_regimes, split_by_regime, regime_summary
from src.statistical_tests import (random_walk_forecast,
                                    compute_random_walk_metrics,
                                    build_dm_table)
from src.backtesting       import (run_backtest, regime_conditional_strategy,
                                    backtest_summary_table)
from src.visualization     import (
    plot_returns_forecast, plot_price_comparison,
    plot_all_models_prices, plot_garch_volatility,
    plot_heatmap, plot_ranking, plot_dashboard,
    plot_regime_performance, plot_all_models_regime,
    plot_dm_heatmap, plot_rolling_vol_regimes,
    plot_hit_rate_heatmap, plot_sharpe_heatmap,
)

from src.models.arima     import run_arima_fold
from src.models.garch     import run_garch_fold
from src.models.ml_models import (run_rf_fold, run_xgboost_fold,
                                   run_gbm_fold, run_svr_fold, run_dt_fold)
from src.models.dl_models import (run_lstm_fold, run_gru_fold,
                                   run_bilstm_fold, run_transformer_fold,
                                   run_tcn_fold, run_cnn_lstm_fold)

START = "2010-01-01"
END   = "2026-05-01"   # aggiornato — include dati fino ad oggi

MODELS = [
    ("Random_Walk",       None),
    ("ARIMA",             run_arima_fold),
    ("Decision_Tree",     run_dt_fold),
    ("Random_Forest",     run_rf_fold),
    ("Gradient_Boosting", run_gbm_fold),
    ("XGBoost",           run_xgboost_fold),
    ("SVR",               run_svr_fold),
    ("LSTM",              run_lstm_fold),
    ("GRU",               run_gru_fold),
    ("BiLSTM",            run_bilstm_fold),
    ("Transformer",       run_transformer_fold),
    ("TCN",               run_tcn_fold),
    ("CNN_LSTM",          run_cnn_lstm_fold),
]

DL_MODELS = {"LSTM", "GRU", "BiLSTM", "Transformer", "TCN", "CNN_LSTM"}
ML_MODELS = {"Decision_Tree", "Random_Forest", "Gradient_Boosting",
             "XGBoost", "SVR"}


def p(folder, filename):
    import os
    path = f"results/plots/{folder}/{filename}.png"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


def run_pipeline():
    results_list   = []
    bt_results_all = {}

    # ── Carica tutti gli asset prima del loop ─────────────────────────────────
    print("\nCaricamento dati...")
    all_dfs = {}
    for metal_name, ticker in METALS.items():
        all_dfs[metal_name] = load_and_preprocess(
            metal_name, ticker, start=START, end=END)
        n = len(all_dfs[metal_name])
        print(f"  {metal_name}: {n} osservazioni")

    # ── Loop principale per asset ─────────────────────────────────────────────
    for metal_name, ticker in METALS.items():
        print(f"\n{'='*64}")
        print(f"  ASSET: {metal_name}  ({ticker})")
        print(f"{'='*64}")

        df = all_dfs[metal_name]
        n  = len(df)

        # Cross-asset: tutti gli asset tranne quello corrente
        cross_asset_dfs = {k: v for k, v in all_dfs.items()
                           if k != metal_name}

        # ── Regime classification ─────────────────────────────────────────────
        regimes = classify_regimes(df)
        print(f"\n  Regime:\n{regime_summary(df).to_string()}")

        plot_rolling_vol_regimes(
            df, regimes, asset_name=metal_name,
            save_path=p("04_volatility_regimes",
                        f"{metal_name}_rolling_volatility_with_regimes"))

        folds = get_walk_forward_folds(n)
        print(f"\n  Walk-forward: {len(folds)} folds × 21 giorni "
              f"= {len(folds)*21} giorni OOS\n")

        all_true     = {m: [] for m, _ in MODELS}
        all_pred     = {m: [] for m, _ in MODELS}
        all_dates    = {m: [] for m, _ in MODELS}
        all_fmetrics = {m: [] for m, _ in MODELS}

        # ── Loop fold ─────────────────────────────────────────────────────────
        for fi, (train_idx, test_idx) in enumerate(folds):
            print(f"  Fold {fi+1}/{len(folds)}  "
                  f"({df.index[test_idx[0]].date()} → "
                  f"{df.index[test_idx[-1]].date()})")

            y_true_fold = df["log_return"].values[test_idx]
            dates_fold  = df.index[test_idx]

            for model_name, run_fn in MODELS:
                if run_fn is None:
                    y_pred = random_walk_forecast(y_true_fold)
                    dates  = dates_fold
                else:
                    try:
                        if model_name in DL_MODELS:
                            result = run_fn(df, train_idx, test_idx,
                                            cross_asset_dfs=cross_asset_dfs)
                        elif model_name in ML_MODELS:
                            result = run_fn(df, train_idx, test_idx,
                                            cross_asset_dfs=cross_asset_dfs)
                        else:
                            result = run_fn(df, train_idx, test_idx)

                        dates, y_true_fold, y_pred, _ = result

                    except Exception as e:
                        print(f"    {model_name}: ERRORE {e}")
                        all_fmetrics[model_name].append(
                            {"RMSE": None, "MAE": None, "MAPE": None})
                        continue

                n_align    = min(len(y_true_fold), len(y_pred), len(dates_fold))
                y_true_aln = np.array(y_true_fold)[-n_align:]
                y_pred_aln = np.array(y_pred)[-n_align:]
                dates_aln  = dates_fold[-n_align:]

                metrics = compute_metrics(y_true_aln, y_pred_aln)
                all_true[model_name].append(y_true_aln)
                all_pred[model_name].append(y_pred_aln)
                all_dates[model_name].append(dates_aln)
                all_fmetrics[model_name].append(metrics)
                print(f"    {model_name:22s}  "
                      f"RMSE={metrics['RMSE']:.6f}  "
                      f"MAE={metrics['MAE']:.6f}")

        # ── GARCH ─────────────────────────────────────────────────────────────
        print(f"\n  [GARCH — Volatilità]")
        g_real_all, g_fc_all, g_dates_all = [], [], []
        for fi, (train_idx, test_idx) in enumerate(folds):
            try:
                gd, gr, gf, gp = run_garch_fold(df, train_idx, test_idx)
                g_real_all.append(gr)
                g_fc_all.append(gf)
                g_dates_all.append(df.index[test_idx])
                gm = compute_metrics(gr, gf)
                print(f"    Fold {fi+1}: Vol-RMSE={gm['RMSE']:.6f}  "
                      f"persistence={gp['persistence']:.4f}")
            except Exception as e:
                print(f"    Fold {fi+1}: GARCH ERRORE {e}")

        # ── Aggregazione metriche ─────────────────────────────────────────────
        print(f"\n  ── Risultati Aggregati ──")
        for model_name, _ in MODELS:
            agg = aggregate_fold_results(all_fmetrics[model_name])
            print(f"    {model_name:22s}  RMSE={agg['RMSE']}  "
                  f"MAE={agg['MAE']}")
            results_list.append({
                "Asset": metal_name,
                "Model": model_name.replace("_", " "),
                **agg
            })

        # ── Concatenazione previsioni ─────────────────────────────────────────
        concat = {}
        for model_name, _ in MODELS:
            if not all_true[model_name]:
                continue
            dates_concat = all_dates[model_name][0]
            for d in all_dates[model_name][1:]:
                dates_concat = dates_concat.append(d)
            concat[model_name] = {
                "y_true": np.concatenate(all_true[model_name]),
                "y_pred": np.concatenate(all_pred[model_name]),
                "dates":  dates_concat,
            }

        # ── Diebold-Mariano ───────────────────────────────────────────────────
        print(f"\n  ── Diebold-Mariano ──")
        dm_preds = {
            mn.replace("_", " "): concat[mn]["y_pred"]
            for mn, _ in MODELS
            if mn in concat and mn != "Random_Walk"
        }
        y_true_all = concat["Random_Walk"]["y_true"]
        dm_table   = build_dm_table(y_true_all, dm_preds)
        print(dm_table[["DM Stat", "p-value", "Sig. (5%)"]].to_string())
        dm_table.to_csv(f"results/DM_test_{metal_name}.csv")

        plot_dm_heatmap(
            dm_table, asset_name=metal_name,
            save_path=p("06_diebold_mariano",
                        f"{metal_name}_DM_test_vs_RandomWalk"))

        # ── Regime analysis ───────────────────────────────────────────────────
        print(f"\n  ── Regime Analysis ──")
        regime_results = {}
        for model_name, _ in MODELS:
            if model_name not in concat:
                continue
            c = concat[model_name]
            splits = split_by_regime(
                c["y_true"], c["y_pred"], c["dates"], regimes)
            label = model_name.replace("_", " ")
            regime_results[label] = {}
            for regime, (yt, yp) in splits.items():
                m = compute_metrics(yt, yp)
                regime_results[label][regime] = m
                print(f"    {model_name:22s} [{regime:8s}]  "
                      f"RMSE={m['RMSE']:.6f}")

        plot_all_models_regime(
            regime_results, asset_name=metal_name, metric="RMSE",
            save_path=p("05_regime_performance",
                        f"{metal_name}_RMSE_by_regime_all_models"))

        # ── BACKTESTING ───────────────────────────────────────────────────────
        print(f"\n  ── Backtesting ──")
        bt_results = {}
        for model_name, _ in MODELS:
            if model_name not in concat:
                continue
            c  = concat[model_name]
            bt = run_backtest(c["y_true"], c["y_pred"],
                              transaction_cost=0.0001)
            bt_results[model_name.replace("_", " ")] = bt
            print(f"    {model_name:22s}  "
                  f"Sharpe={bt['Sharpe Ratio']:6.3f}  "
                  f"DA={bt['Directional Acc.']:5.1f}%  "
                  f"MaxDD={bt['Max Drawdown (%)']:6.2f}%")

        bt_df = backtest_summary_table(bt_results)
        bt_df.to_csv(f"results/backtest_{metal_name}.csv")
        bt_results_all[metal_name] = bt_results

        # ── REGIME-CONDITIONAL STRATEGY ───────────────────────────────────────
        print(f"\n  ── Regime-Conditional Strategy ──")
        rcs_results = {}
        for model_name, _ in MODELS:
            if model_name not in concat:
                continue
            c          = concat[model_name]
            y_pred_rcs = regime_conditional_strategy(
                c["y_pred"], c["dates"], regimes)
            bt_rcs = run_backtest(c["y_true"], y_pred_rcs,
                                  transaction_cost=0.0001)
            rcs_results[model_name.replace("_", " ")] = bt_rcs
            print(f"    {model_name:22s} [RCS]  "
                  f"Sharpe={bt_rcs['Sharpe Ratio']:6.3f}  "
                  f"DA={bt_rcs['Directional Acc.']:5.1f}%")

        rcs_df = backtest_summary_table(rcs_results)
        rcs_df.to_csv(f"results/backtest_rcs_{metal_name}.csv")

        # ── Plot individuali ──────────────────────────────────────────────────
        model_pred_prices = {}
        for model_name, _ in MODELS:
            if model_name not in concat:
                continue
            c     = concat[model_name]
            label = model_name.replace("_", " ")

            plot_returns_forecast(
                pd.Series(c["y_true"], index=c["dates"]),
                pd.Series(c["y_pred"], index=c["dates"]),
                model_name=label, asset_name=metal_name,
                save_path=p("01_logreturn_forecast",
                            f"{metal_name}_{model_name}_logreturn_forecast_vs_actual"))

            prices_before = df["Close"][df.index < c["dates"][0]]
            last_price    = float(prices_before.iloc[-1])
            pred_prices   = reconstruct_prices(last_price, c["y_pred"])
            pred_series   = pd.Series(pred_prices, index=c["dates"])
            real_prices   = df["Close"].reindex(c["dates"], method="nearest")
            model_pred_prices[label] = pred_series

            plot_price_comparison(
                real_prices=real_prices,
                predicted_prices=pred_series,
                model_name=label, asset_name=metal_name,
                save_path=p("02_predicted_vs_real_price",
                            f"{metal_name}_{model_name}_predicted_vs_real_price"))

        if model_pred_prices:
            ref_dates   = list(model_pred_prices.values())[0].index
            real_prices = df["Close"].reindex(ref_dates, method="nearest")
            plot_all_models_prices(
                real_prices=real_prices,
                pred_prices_dict=model_pred_prices,
                asset_name=metal_name,
                save_path=p("03_all_models_price_overlay",
                            f"{metal_name}_all_models_predicted_vs_real_price"))

        if g_real_all:
            g_dates_concat = g_dates_all[0]
            for d in g_dates_all[1:]:
                g_dates_concat = g_dates_concat.append(d)
            plot_garch_volatility(
                pd.Series(np.concatenate(g_real_all), index=g_dates_concat),
                pd.Series(np.concatenate(g_fc_all),   index=g_dates_concat),
                asset_name=metal_name,
                save_path=p("04_volatility_regimes",
                            f"{metal_name}_GARCH_volatility_forecast_vs_realized"))

    # ── Output finale ─────────────────────────────────────────────────────────
    results_df = save_results(results_list, path="results/metrics.csv")
    valid_df   = results_df.dropna(subset=["RMSE"])

    print("\n" + "="*64)
    print("  RANKING FINALE — RMSE medio")
    print("="*64)
    ranking = (valid_df.groupby("Model")[["RMSE", "MAE"]]
               .mean().sort_values("RMSE"))
    print(ranking.to_string())

    print("\n" + "="*64)
    print("  RANKING FINALE — Sharpe medio")
    print("="*64)
    sharpe_rows = []
    for asset_name, bt_res in bt_results_all.items():
        for model_name, bt in bt_res.items():
            sharpe_rows.append({
                "Asset": asset_name, "Model": model_name,
                "Sharpe": bt["Sharpe Ratio"],
                "MaxDD":  bt["Max Drawdown (%)"],
                "DA":     bt["Directional Acc."]
            })
    sharpe_df = pd.DataFrame(sharpe_rows)
    sharpe_df.to_csv("results/backtesting_all_assets.csv", index=False)
    sharpe_ranking = (sharpe_df.groupby("Model")[["Sharpe", "MaxDD", "DA"]]
                      .mean().sort_values("Sharpe", ascending=False))
    print(sharpe_ranking.to_string())

    for metric in ["RMSE", "MAE"]:
        plot_heatmap(valid_df, metric=metric,
                      save_path=p("07_heatmaps",
                                  f"heatmap_{metric}_all_models_all_assets"))
        plot_ranking(valid_df, metric=metric,
                      save_path=p("08_model_ranking",
                                  f"model_ranking_mean_{metric}_all_assets"))
    plot_dashboard(valid_df,
                    save_path=p("09_dashboard",
                                "summary_dashboard_all_models_all_assets"))

    print("\n✅  Pipeline completa.")
    print("    results/metrics.csv")
    print("    results/backtest_<asset>.csv")
    print("    results/backtest_rcs_<asset>.csv")
    print("    results/backtesting_all_assets.csv")

    return results_df


if __name__ == "__main__":
    run_pipeline()